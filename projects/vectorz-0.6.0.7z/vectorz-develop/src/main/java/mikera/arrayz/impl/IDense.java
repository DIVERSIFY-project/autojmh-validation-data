package mikera.arrayz.impl;

/**
 * Marker interface for matrices using dense storage.
 * 
 * @author Mike
 *
 */
public interface IDense {
	// just a marker interface

}
