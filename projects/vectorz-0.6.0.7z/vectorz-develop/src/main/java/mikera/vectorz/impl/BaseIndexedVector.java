package mikera.vectorz.impl;

import mikera.vectorz.util.VectorzException;

/**
 * Abstract base class for vectors that index into other sources
 * @author Mike
 */
@SuppressWarnings("serial")
abstract class BaseIndexedVector extends ASizedVector {
	protected final int[] indexes;

	protected BaseIndexedVector(int length) {
		super(length);
		
		indexes=new int[length];
	}
	
	public BaseIndexedVector(int[] indexes) {
		super(indexes.length);
		this.indexes=indexes;
	}
	
	@Override
	public boolean isView() {
		return true;
	}
	
	@Override
	public void validate() {
		if (length!=indexes.length) throw new VectorzException("Wrong index length");
		super.validate();
	}
	
	@Override
	public double elementSquaredSum() {
		double result=0.0;
		for (int i=0; i<length; i++) {
			double x=unsafeGet(i);
			result+=x*x;
		}
		return result;
	}
}
