package mikera.vectorz.ops;

import mikera.vectorz.Op;

public abstract class APolynomialOp extends Op {

	// no special methods yet
}
