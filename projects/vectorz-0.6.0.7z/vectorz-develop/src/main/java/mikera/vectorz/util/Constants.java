package mikera.vectorz.util;

public class Constants {

	public static final Double ZERO_DOUBLE = Double.valueOf(0.0);
	
	public static final long PRINT_THRESHOLD = 10000;

}
