package mikera.transformz.marker;

/**
 * Marker interface for specialised transforms
 * 
 * @author Mike
 */
public interface ISpecialisedTransform {
	
	// no implementation, just a marker interface
}
