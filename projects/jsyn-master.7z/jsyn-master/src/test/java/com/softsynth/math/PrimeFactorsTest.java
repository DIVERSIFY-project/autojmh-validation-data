package com.softsynth.math;

import junit.framework.TestCase;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class PrimeFactorsTest {

    @Test
    public void testSubtract() throws Exception {
        PrimeFactors p = new PrimeFactors(10, 10);
        assertTrue(p.getFactors().length > 0);
    }
}