/*
 * Copyright 2010 Phil Burk, Mobileer Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.jsyn.integration;

import com.jsyn.JSyn;
import com.jsyn.Synthesizer;
import com.jsyn.ports.UnitInputPort;
import com.jsyn.scope.AudioScope;
import com.jsyn.swing.DoubleBoundedRangeModel;
import com.jsyn.swing.JAppletFrame;
import com.jsyn.swing.PortModelFactory;
import com.jsyn.swing.RotaryTextController;
import com.jsyn.unitgen.LineOut;
import com.jsyn.unitgen.SineOscillator;
import com.jsyn.unitgen.SineOscillatorPhaseModulated;
import org.junit.After; import org.junit.Before; import org.junit.Test; import static junit.framework.Assert.assertEquals; import static junit.framework.Assert.assertTrue;

import javax.swing.*;
import java.awt.*;

/**
 * Play a tone using a phase modulated sinewave oscillator. Phase modulation (PM) is very similar to
 * frequency modulation (FM) but is easier to control.
 * 
 * @author Phil Burk (C) 2010 Mobileer Inc
 */
public class TestHearSinePM  {
    private static final long serialVersionUID = -2704222221111608377L;
    private Synthesizer synth;
    SineOscillatorPhaseModulated carrier;
    SineOscillator modulator;
    LineOut lineOut;
    AudioScope scope;


    public void init() {
        synth = JSyn.createSynthesizer();
        // Add a tone generator.
        synth.add(modulator = new SineOscillator());
        // Add a trigger.
        synth.add(carrier = new SineOscillatorPhaseModulated());
        // Add an output mixer.
        synth.add(lineOut = new LineOut());

        modulator.output.connect(carrier.modulation);
        carrier.output.connect(0, lineOut.input, 0);
        carrier.output.connect(0, lineOut.input, 1);
        modulator.amplitude.setup(0.0, 1.0, 10.0);
        carrier.amplitude.setup(0.0, 1.0, 1.0);
    }


    private RotaryTextController setupPortKnob(UnitInputPort port, String label) {
        DoubleBoundedRangeModel model = PortModelFactory.createExponentialModel(port);
        RotaryTextController knob = new RotaryTextController(model, 10);
        knob.setBorder(BorderFactory.createTitledBorder(label));
        knob.setTitle(label);
        return knob;
    }


@Test
    public void testTestHearSinePM() {
        init();
        // Start synthesizer using default stereo output at 44100 Hz.
        synth.start();
        //scope.start();
        // We only need to start the LineOut. It will pull data from the
        // oscillator.
        lineOut.start();
        // Sleep while the sound is generated in the background.
        try {
            double time = synth.getCurrentTime();
            // Sleep for a few seconds.
            synth.sleepUntil(time + 1.0);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Stop playing. -------------------");
        // Stop everything.
        synth.stop();
    }

    public void stop() {
        //scope.stop();
        synth.stop();
    }


}
