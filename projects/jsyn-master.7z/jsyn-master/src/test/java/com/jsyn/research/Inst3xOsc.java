package com.jsyn.research;

import com.jsyn.ports.UnitInputPort;
import com.jsyn.ports.UnitOutputPort;
import com.jsyn.unitgen.*;
import com.jsyn.util.VoiceDescription;
import com.softsynth.shared.time.TimeStamp;

/**
 * Created by marodrig on 08/07/2015.
 */
public class Inst3xOsc extends Circuit implements UnitVoice {

    private static final long serialVersionUID = -2704222221111608377L;
    private Synth3xOsc osc;
    private FilterLowPass filter;
    private EnvelopeDAHDSR ampEnv;
    private EnvelopeDAHDSR filterEnv;
    private Add cutoffAdder;
    private Multiply frequencyScaler;

    public UnitInputPort amplitude;
    public UnitInputPort frequency;
    /**
     * This scales the frequency value. You can use this to modulate a group of instruments using a
     * shared LFO and they will stay in tune.
     */
    public UnitInputPort pitchModulation;
    public UnitInputPort cutoff;
    public UnitInputPort cutoffRange;
    public UnitInputPort Q;

    public Inst3xOsc() {
        add(frequencyScaler = new Multiply());
        // Add a tone generator.
        add(osc = new Synth3xOsc());

        osc.setOsc1Kind(Synth3xOsc.OscKind.Triangle);
        osc.setOsc1Kind(Synth3xOsc.OscKind.Square);
        osc.setOsc1Kind(Synth3xOsc.OscKind.Sine);

        // Use an envelope to control the amplitude.
        add(ampEnv = new EnvelopeDAHDSR());

        // Use an envelope to control the filter cutoff.
        add(filterEnv = new EnvelopeDAHDSR());
        add(filter = new FilterLowPass());
        add(cutoffAdder = new Add());

        filterEnv.output.connect(cutoffAdder.inputA);
        cutoffAdder.output.connect(filter.frequency);
        frequencyScaler.output.connect(osc.frequency);
        osc.output.connect(filter.input);
        filter.output.connect(ampEnv.amplitude);

        addPort(amplitude = osc.amplitude, "Amplitude");
        addPort(frequency = frequencyScaler.inputA, "Frequency");
        addPort(pitchModulation = frequencyScaler.inputB, "PitchMod");
        addPort(cutoff = cutoffAdder.inputB, "Cutoff");
        addPort(cutoffRange = filterEnv.amplitude, "CutoffRange");
        addPort(Q = filter.Q);

        ampEnv.export(this, "Amp");
        filterEnv.export(this, "Filter");

        frequency.setup(osc.frequency);
        pitchModulation.setup(0.2, 1.0, 4.0);
        cutoff.setup(filter.frequency);
        cutoffRange.setup(filter.frequency);

        // Make the circuit turn off when the envelope finishes to reduce CPU load.
        ampEnv.setupAutoDisable(this);

        usePreset(0);
    }

    @Override
    public void noteOff(TimeStamp timeStamp) {
        ampEnv.input.off(timeStamp);
        filterEnv.input.off(timeStamp);
    }

    @Override
    public void noteOn(double freq, double ampl, TimeStamp timeStamp) {
        frequency.set(freq, timeStamp);
        amplitude.set(ampl, timeStamp);

        ampEnv.input.on(timeStamp);
        filterEnv.input.on(timeStamp);
    }

    @Override
    public UnitOutputPort getOutput() {
        return ampEnv.output;
    }

    @Override
    public void usePreset(int presetIndex) {
        int n = presetIndex % presetNames.length;
        switch (n) {
            case 0:
                ampEnv.attack.set(0.01);
                ampEnv.decay.set(0.2);
                ampEnv.release.set(1.0);
                cutoff.set(500.0);
                cutoffRange.set(500.0);
                filter.Q.set(1.0);
                break;
            case 1:
                ampEnv.attack.set(0.5);
                ampEnv.decay.set(0.3);
                ampEnv.release.set(0.2);
                cutoff.set(500.0);
                cutoffRange.set(500.0);
                filter.Q.set(3.0);
                break;
            case 2:
            default:
                ampEnv.attack.set(0.1);
                ampEnv.decay.set(0.3);
                ampEnv.release.set(0.5);
                cutoff.set(2000.0);
                cutoffRange.set(500.0);
                filter.Q.set(2.0);
                break;
        }
    }

    static String[] presetNames = {
            "FastSaw", "SlowSaw", "BrightSaw"
    };

    static class MyVoiceDescription extends VoiceDescription {
        String[] tags = {
                "electronic", "filter", "clean"
        };

        public MyVoiceDescription() {
            super("SubtractiveSynth", presetNames);
        }

        @Override
        public UnitVoice createUnitVoice() {
            return new Inst3xOsc();
        }

        @Override
        public String[] getTags(int presetIndex) {
            return tags;
        }

        @Override
        public String getVoiceClassName() {
            return Inst3xOsc.class.getName();
        }
    }

    public static VoiceDescription getVoiceDescription() {
        return new MyVoiceDescription();
    }


}
