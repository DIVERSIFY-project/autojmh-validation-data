/*
 * Copyright 2009 Phil Burk, Mobileer Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.jsyn.research;

import com.jsyn.unitgen.UnitOscillator;

/**
 * Narrow impulse oscillator. An impulse is only one sample wide. It is useful for pinging filters
 * or generating an "impulse response".
 * 
 * @author Phil Burk (C) 2009 Mobileer Inc
 */
public class ConstantSignal extends UnitOscillator {

    @Override
    public void generate(int start, int limit) {
        double[] outputs = output.getValues();
        double[] freqs = frequency.getValues();

        // Variables have a single value.
        for (int i = start; i < limit; i++) {
            outputs[i] = freqs[i] > 0 ? 0.5 : 0.0;
        }
    }

}
