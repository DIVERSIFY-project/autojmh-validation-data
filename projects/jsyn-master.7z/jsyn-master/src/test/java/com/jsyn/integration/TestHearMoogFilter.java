/*
 * Copyright 2010 Phil Burk, Mobileer Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.jsyn.integration;

import com.jsyn.JSyn;
import com.jsyn.Synthesizer;
import com.jsyn.ports.UnitInputPort;
import com.jsyn.scope.AudioScope;
import com.jsyn.scope.AudioScopeProbe;
import com.jsyn.swing.DoubleBoundedRangeModel;
import com.jsyn.swing.JAppletFrame;
import com.jsyn.swing.PortModelFactory;
import com.jsyn.swing.RotaryTextController;
import com.jsyn.unitgen.*;
import org.junit.After; import org.junit.Before; import org.junit.Test; import static junit.framework.Assert.assertEquals; import static junit.framework.Assert.assertTrue;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

/**
 * Play a sawtooth through a 4-pole filter.
 * 
 * @author Phil Burk (C) 2010 Mobileer Inc
 */
public class TestHearMoogFilter  {

    private Synthesizer synth;
    private UnitOscillator oscillator;
    private FilterFourPoles filterMoog;
    private FilterLowPass filterBiquad;
    private LinearRamp rampCutoff;
    private PassThrough tieQ;
    private PassThrough mixer;
    private LineOut lineOut;

    private AudioScope scope;
    private AudioScopeProbe moogProbe;

    public void init() {
        synth = JSyn.createSynthesizer();
        synth.add(oscillator = new SawtoothOscillatorBL());
        synth.add(rampCutoff = new LinearRamp());
        synth.add(tieQ = new PassThrough());
        synth.add(filterMoog = new FilterFourPoles());
        synth.add(filterBiquad = new FilterLowPass());
        synth.add(mixer = new PassThrough());
        synth.add(lineOut = new LineOut());

        oscillator.output.connect(filterMoog.input);
        oscillator.output.connect(filterBiquad.input);
        rampCutoff.output.connect(filterMoog.frequency);
        rampCutoff.output.connect(filterBiquad.frequency);
        rampCutoff.time.set(0.050);
        tieQ.output.connect(filterMoog.Q);
        tieQ.output.connect(filterBiquad.Q);
        filterMoog.output.connect(mixer.input);
        mixer.output.connect(0, lineOut.input, 0);
        mixer.output.connect(0, lineOut.input, 1);

        filterBiquad.amplitude.set(0.1);
        oscillator.frequency.setup(50.0, 130.0, 3000.0);
        oscillator.amplitude.setup(0.0, 0.336, 1.0);
        rampCutoff.input.setup(50.0, 400.0, 4000.0);
        tieQ.input.setup(0.1, 0.7, 10.0);
    }

@Test
    public void testTestHearMoogFilter() {
        init();
        // Start synthesizer using default stereo output at 44100 Hz.
        synth.start();
//        scope.start();
        // We only need to start the LineOut. It will pull data from the
        // oscillator.
        lineOut.start();

        try {
            double time = synth.getCurrentTime();
            // Sleep for a few seconds.
            synth.sleepUntil(time + 1.0);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        stop();
    }


    public void stop() {
//        scope.stop();
        synth.stop();
    }

}
