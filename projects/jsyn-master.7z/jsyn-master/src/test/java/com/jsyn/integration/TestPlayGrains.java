/*
 * Copyright 2011 Phil Burk, Mobileer Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.jsyn.integration;

import com.jsyn.JSyn;
import com.jsyn.Synthesizer;
import com.jsyn.data.FloatSample;
import com.jsyn.ports.UnitInputPort;
import com.jsyn.scope.AudioScope;
import com.jsyn.swing.DoubleBoundedRangeModel;
import com.jsyn.swing.JAppletFrame;
import com.jsyn.swing.PortModelFactory;
import com.jsyn.swing.RotaryTextController;
import com.jsyn.unitgen.ContinuousRamp;
import com.jsyn.unitgen.GrainFarm;
import com.jsyn.unitgen.LineOut;
import com.jsyn.unitgen.SampleGrainFarm;
import com.jsyn.util.SampleLoader;
import com.jsyn.util.WaveRecorder;
import org.junit.After; import org.junit.Before; import org.junit.Test; import static junit.framework.Assert.assertEquals; import static junit.framework.Assert.assertTrue;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

/**
 * Play with Granular Synthesis tools.
 * 
 * @author Phil Burk (C) 2011 Mobileer Inc
 */
public class TestPlayGrains  {
    private static final long serialVersionUID = -8315903842197137926L;
    private Synthesizer synth;
    private LineOut lineOut;
        private GrainFarm grainFarm;
    private ContinuousRamp ramp;
    private static final int NUM_GRAINS = 32;
    private FloatSample sample;
    private WaveRecorder recorder;

    private static final boolean useSample = true;
    private final static boolean useRecorder = false;

    // File sampleFile = new File( "samples/instructions.wav" );
    File sampleFile = new File(
    // "/Users/phil/Work/jsyn/guitar100/Guitar100_Ocean_1#02.aif" );
            "/Users/phil/Music/samples/ChewyMonkeysWhistle.aiff");

@Test
    public void testPlayGrains() {
        synth = JSyn.createSynthesizer();

        try {

            if (useRecorder) {
                File waveFile = new File("temp_recording.wav");
                // Record mono 16 bits.
                recorder = new WaveRecorder(synth, waveFile, 1);
                System.out.println("Writing to WAV file " + waveFile.getAbsolutePath());
            }

            if (useSample) {
                sample = SampleLoader.loadFloatSample(sampleFile);
                SampleGrainFarm sampleGrainFarm = new SampleGrainFarm();
                synth.add(ramp = new ContinuousRamp());
                sampleGrainFarm.setSample(sample);
                ramp.output.connect(sampleGrainFarm.position);
                grainFarm = sampleGrainFarm;
            } else {
                GrainFarm sampleGrainFarm = new GrainFarm();
                grainFarm = sampleGrainFarm;
            }

            synth.add(grainFarm);

            grainFarm.allocate(NUM_GRAINS);

            // Add an output so we can hear the grains.
            synth.add(lineOut = new LineOut());

            grainFarm.getOutput().connect(0, lineOut.input, 0);
            grainFarm.getOutput().connect(0, lineOut.input, 1);

            // Start synthesizer using default stereo output at 44100 Hz.
            synth.start();
            // Start lineOut so it can pull data from other units.
            lineOut.start();

            if (useRecorder) {
                grainFarm.output.connect(0, recorder.getInput(), 0);
                // When we start the recorder it will pull data from the
                // oscillator
                // and sweeper.
                recorder.start();
            }

            // We only need to start the LineOut. It will pull data from the
            // oscillator.
            lineOut.start();

            try {
                double time = synth.getCurrentTime();
                // Sleep for a few seconds.
                synth.sleepUntil(time + 1.0);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public void stop() {
        try {
            if (recorder != null) {
                recorder.stop();
                recorder.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        synth.stop();
    }

}
