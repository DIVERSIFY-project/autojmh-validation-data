package com.jsyn.research;

import com.jsyn.unitgen.UnitVoice;
import com.jsyn.util.*;
import com.jsyn.util.Instrument;
import com.softsynth.shared.time.TimeStamp;

import javax.sound.midi.*;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

/**
 * Class that loads a MIDI file and Synths a song out of it
 *
 * Created by marodrig on 08/07/2015.
 */
public class MIDIScore {

    public static final float[] NOTE_FREQ = {
            16.35f,//C0
            17.32f,//C#0/Db0
            18.35f,//D0
            19.45f,//D#0/Eb0
            20.60f,//E0
            21.83f,//F0
            23.12f,//F#0/Gb0
            24.50f,//G0
            25.96f,//G#0/Ab0
            27.50f,//A0
            29.14f,//A#0/Bb0
            30.87f,//B0
            32.70f,//C1
            34.65f,//C#1/Db1
            36.71f,//D1
            38.89f,//D#1/Eb1
            41.20f,//E1
            43.65f,//F1
            46.25f,//F#1/Gb1
            49.00f,//G1
            51.91f,//G#1/Ab1
            55.00f,//A1
            58.27f,//A#1/Bb1
            61.74f,//B1
            65.41f,//C2
            69.30f,//C#2/Db2
            73.42f,//D2
            77.78f,//D#2/Eb2
            82.41f,//E2
            87.31f,//F2
            92.50f,//F#2/Gb2
            98.00f,//G2
            103.83f,//G#2/Ab2
            110.00f,//A2
            116.54f,//A#2/Bb2
            123.47f,//B2
            130.81f,//C3
            138.59f,//C#3/Db3
            146.83f,//D3
            155.56f,//D#3/Eb3
            164.81f,//E3
            174.61f,//F3
            185.00f,//F#3/Gb3
            196.00f,//G3
            207.65f,//G#3/Ab3
            220.00f,//A3
            233.08f,//A#3/Bb3
            246.94f,//B3
            261.63f,//C4
            277.18f,//C#4/Db4
            293.66f,//D4
            311.13f,//D#4/Eb4
            329.63f,//E4
            349.23f,//F4
            369.99f,//F#4/Gb4
            392.00f,//G4
            415.30f,//G#4/Ab4
            440.00f,//A4
            466.16f,//A#4/Bb4
            493.88f,//B4
            523.25f,//C5
            554.37f,//C#5/Db5
            587.33f,//D5
            622.25f,//D#5/Eb5
            659.25f,//E5
            698.46f,//F5
            739.99f,//F#5/Gb5
            783.99f,//G5
            830.61f,//G#5/Ab5
            880.00f,//A5
            932.33f,//A#5/Bb5
            987.77f,//B5
            1046.50f,//C6
            1108.73f,//C#6/Db6
            1174.66f,//D6
            1244.51f,//D#6/Eb6
            1318.51f,//E6
            1396.91f,//F6
            1479.98f,//F#6/Gb6
            1567.98f,//G6
            1661.22f,//G#6/Ab6
            1760.00f,//A6
            1864.66f,//A#6/Bb6
            1975.53f,//B6
            2093.00f,//C7
            2217.46f,//C#7/Db7
            2349.32f,//D7
            2489.02f,//D#7/Eb7
            2637.02f,//E7
            2793.83f,//F7
            2959.96f,//F#7/Gb7
            3135.96f,//G7
            3322.44f,//G#7/Ab7
            3520.00f,//A7
            3729.31f,//A#7/Bb7
            3951.07f,//B7
            4186.01f,//C8
            4434.92f,//C#8/Db8
            4698.63f,//D8
            4978.03f,//D#8/Eb8
            5274.04f,//E8
            5587.65f,//F8
            5919.91f,//F#8/Gb8
            6271.93f,//G8
            6644.88f,//G#8/Ab8
            7040.00f,//A8
            7458.62f,//A#8/Bb8
            7902.13f,//B8
    };

    HashMap<Integer, Instrument> channels;

    public static final int NOTE_ON = ShortMessage.NOTE_ON;

    public static final int NOTE_OFF = ShortMessage.NOTE_OFF;

    /**
     * Path to the MIDI file being read
     */
    private final String midiFile;

    public MIDIScore(String midiFilePath) {
        midiFile = midiFilePath;
        channels = new HashMap<Integer, Instrument>();
    }

    /**
     * Assings a voice to a channel in the MIDI file
     * @param channel
     * @param voice
     */
    public void assignVoiceToChannel(int channel, Instrument voice) {
         channels.put(channel, voice);
    }

    /**
     * Process the MIDI file into notes of the voices
     */
    public void process() throws InvalidMidiDataException, IOException {
        Sequence sequence = MidiSystem.getSequence(new File(midiFile));

        int trackNumber = 0;
        for (Track track :  sequence.getTracks()) {
            if (channels.containsKey(trackNumber)) {
                Instrument voice = channels.get(trackNumber);
                for (int i = 0; i < track.size(); i++) {
                    MidiEvent event = track.get(i);
                    MidiMessage message = event.getMessage();
                    if (message instanceof ShortMessage) {
                        ShortMessage sm = (ShortMessage) message;
                        if (sm.getCommand() == NOTE_ON) {
                            int key = sm.getData1();
                            int velocity = sm.getData2();
                            voice.noteOn(0, NOTE_FREQ[key], velocity, new TimeStamp(event.getTick()));
                        } else if (sm.getCommand() == NOTE_OFF) {
                            voice.noteOff(0, new TimeStamp(event.getTick()));
                        }
                    }
                }
            }
            trackNumber++;
        }
    }

}
