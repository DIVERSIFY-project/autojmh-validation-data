/*
 * Copyright 2010 Phil Burk, Mobileer Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.jsyn.integration;

import com.jsyn.JSyn;
import com.jsyn.Synthesizer;
import com.jsyn.unitgen.*;
import org.junit.After; import org.junit.Before; import org.junit.Test; import static junit.framework.Assert.assertEquals; import static junit.framework.Assert.assertTrue;

/**
 * Play a tone using a JSyn oscillator. Modulate the amplitude using a DAHDSR envelope.
 * 
 * @author Phil Burk (C) 2010 Mobileer Inc
 */
public class TestHearDAHDSR  {

    private static final long serialVersionUID = -2704222221111608377L;
    private Synthesizer synth;
    private UnitOscillator osc;
    // Use a square wave to trigger the envelope.
    private UnitOscillator gatingOsc;
    private EnvelopeDAHDSR dahdsr;
    private LineOut lineOut;

    public void init() {
        synth = JSyn.createSynthesizer();

        // Add a tone generator.
        synth.add(osc = new SineOscillator());
        // Add a trigger.
        synth.add(gatingOsc = new SquareOscillator());
        // Use an envelope to control the amplitude.
        synth.add(dahdsr = new EnvelopeDAHDSR());
        // Add an output mixer.
        synth.add(lineOut = new LineOut());

        gatingOsc.output.connect(dahdsr.input);
        dahdsr.output.connect(osc.amplitude);
        dahdsr.attack.setup(0.001, 0.01, 2.0);
        osc.output.connect(0, lineOut.input, 0);
        osc.output.connect(0, lineOut.input, 1);

        gatingOsc.frequency.setup(0.001, 0.5, 10.0);
        gatingOsc.frequency.setName("Rate");

        osc.frequency.setup(50.0, 440.0, 2000.0);
        osc.frequency.setName("Freq");

    }

@Test
    public void testsTestHearDAHDSR() {
        init();
        // Start synthesizer using default stereo output at 44100 Hz.
        synth.start();
        // We only need to start the LineOut. It will pull data from the
        // oscillator.
        lineOut.start();

        try {
            double time = synth.getCurrentTime();
            // Sleep for a few seconds.
            synth.sleepUntil(time + 1.0);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Stop playing. -------------------");
        // Stop everything.
        synth.stop();
    }

}
