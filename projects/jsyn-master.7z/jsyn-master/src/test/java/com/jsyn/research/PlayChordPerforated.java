/*
 * Copyright 2009 Phil Burk, Mobileer Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.jsyn.research;

import com.jsyn.JSyn;
import com.jsyn.Synthesizer;
import com.jsyn.unitgen.*;
import com.jsyn.util.VoiceAllocator;
import com.jsyn.util.WaveRecorder;
import com.softsynth.math.AudioMath;
import com.softsynth.shared.time.TimeStamp;

import javax.sound.midi.InvalidMidiDataException;
import java.io.File;
import java.io.IOException;

/**
 * Play chords and melody using the VoiceAllocator.
 * 
 * @author Phil Burk (C) 2009 Mobileer Inc
 */
public class PlayChordPerforated {
    private static final int MAX_VOICES = 8;
    private Synthesizer synth;
    private VoiceAllocator allocator;
    private VoiceAllocator allocatorSignal;
    private LineOut lineOut;
    /** Number of seconds to generate music in advance of presentation-time. */
    private double advance = 0.2;
    private double secondsPerBeat = 0.6;
    // on time over note duration
    private double dutyCycle = 0.8;
    private double measure = secondsPerBeat * 4.0;
    private SineOscillator[] voices;
    private ConstantSignal[] signal;
    private WaveRecorder recorder;

    //Hack to activate the ADSR filter
    //SquareOscillator gate;

    private void test() throws IOException, InvalidMidiDataException {
        synth = JSyn.createSynthesizer();
        synth.setRealTime(false);

        File waveFile = new File("midi_synthesized2.wav");
        // Default is stereo, 16 bits.
        recorder = new WaveRecorder(synth, waveFile);
        System.out.println("Writing to WAV file " + waveFile.getAbsolutePath());

        // Add an output.
        //synth.add(lineOut = new LineOut());


        voices = new SineOscillator[MAX_VOICES];
        signal = new ConstantSignal[MAX_VOICES];
        for (int i = 0; i < MAX_VOICES; i++) {
            SineOscillator voice = new SineOscillator();
            signal[i] = new ConstantSignal();
            EnvelopeDAHDSR dahdsr = new EnvelopeDAHDSR();
            dahdsr.attack.setup(0.001, 0.01, 2.0);
            dahdsr.hold.setup(0.001, 0.34, 2.0);
            dahdsr.decay.setup(0.001, 0.2, 8.0);
            dahdsr.sustain.setup(0.001, 0.17, 1.0);
            dahdsr.release.setup(0.001, 0.14, 8.0);
            //dahdsr.
            synth.add(dahdsr);
            synth.add(voice);
            synth.add(signal[i]);

            signal[i].getOutput().connect(dahdsr.input);
            dahdsr.getOutput().connect(voice.amplitude);
            voice.getOutput().connect(0, recorder.getInput(), 0);
            voice.getOutput().connect(0, recorder.getInput(), 1);

            voices[i] = voice;
        }
        allocator = new VoiceAllocator(voices);
        allocatorSignal = new VoiceAllocator(signal);


        // Start synthesizer using default stereo output at 44100 Hz.
        synth.start();
        // When we start the recorder it will pull data from the oscillator
        // and sweeper.
        recorder.start();

        // We only need to start the LineOut. It will pull data from the
        // voices.
        //lineOut.start();

        // Get synthesizer time in seconds.
        double timeNow = synth.getCurrentTime();

        // Advance to a near future time so we have a clean start.
        double time = timeNow + 1.0;

        System.out.println("Playing notes");
        //MIDIScore score = new MIDIScore("C:\\MarcelStuff\\DATA\\europe-final_countdown.mid");
        //score.assignVoiceToChannel(1, allocator);
        //score.process();

        try {
            int tonic = 60 - 12;
            for (int i = 0; i < 4; i++) {
                playMajorMeasure1(time, tonic);
                time += measure;
                catchUp(time);
                playMajorMeasure1(time, tonic + 4);
                time += measure;
                catchUp(time);
                playMajorMeasure1(time, tonic + 7);
                time += measure;
                catchUp(time);
                playMinorMeasure1(time, tonic + 2); // minor chord
                time += measure;
                catchUp(time);
            }
            time += secondsPerBeat;
            catchUp(time);

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Done");


        // Stop everything.
        recorder.stop();
        recorder.close();
        System.out.println("Recorder stop");
        synth.stop();
        System.out.println("Synth stop");
    }

    private void playMinorMeasure1(double time, int base) throws InterruptedException {
        int p1 = base;
        int p2 = base + 3;
        int p3 = base + 7;
        playChord1(time, p1, p2, p3);
        playNoodle1(time, p1 + 24, p2 + 24, p3 + 24);
    }

    private void playMajorMeasure1(double time, int base) throws InterruptedException {
        int p1 = base;
        int p2 = base + 4;
        int p3 = base + 7;
        playChord1(time, p1, p2, p3);
        playNoodle1(time, p1 + 24, p2 + 24, p3 + 24);
    }

    private void playNoodle1(double time, int p1, int p2, int p3) {
        double secondsPerNote = secondsPerBeat * 0.5;
        for (int i = 0; i < 8; i++) {
            int p = pickFromThree(p1, p2, p3);
            noteOn(time, p);
            noteOff(time + dutyCycle * secondsPerNote, p);
            time += secondsPerNote;
        }
    }

    private int pickFromThree(int p1, int p2, int p3) {
        int r = (int) (Math.random() * 3.0);
        if (r < 1)
            return p1;
        else if (r < 2)
            return p2;
        else
            return p3;
    }

    private void playChord1(double time, int p1, int p2, int p3) throws InterruptedException {
        double dur = dutyCycle * secondsPerBeat;
        playTriad(time, dur, p1, p2, p3);
        time += secondsPerBeat;
        playTriad(time, dur, p1, p2, p3);
        time += secondsPerBeat;
        playTriad(time, dur * 0.25, p1, p2, p3);
        time += secondsPerBeat * 0.25;
        playTriad(time, dur * 0.25, p1, p2, p3);
        time += secondsPerBeat * 0.75;
        playTriad(time, dur, p1, p2, p3);
        time += secondsPerBeat;
    }

    private void playTriad(double time, double dur, int p1, int p2, int p3)
            throws InterruptedException {
        noteOn(time, p1);
        noteOn(time, p2);
        noteOn(time, p3);
        double offTime = time + dur;
        noteOff(offTime, p1);
        noteOff(offTime, p2);
        noteOff(offTime, p3);
    }

    private void catchUp(double time) throws InterruptedException {
        synth.sleepUntil(time - advance);
    }

    private void noteOff(double time, int noteNumber) {
        TimeStamp timeStamp = new TimeStamp(time);
//        signal[noteNumber].noteOff(timeStamp);
        allocator.noteOff(noteNumber, timeStamp);
        allocatorSignal.noteOff(noteNumber, timeStamp);
    }

    private void noteOn(double time, int noteNumber) {
        double frequency = AudioMath.pitchToFrequency(noteNumber);
        double amplitude = 0.2;
        TimeStamp timeStamp = new TimeStamp(time);
//        signal[noteNumber].noteOn(frequency, amplitude, timeStamp);
        allocator.noteOn(noteNumber, frequency, amplitude, timeStamp);
        allocatorSignal.noteOn(noteNumber, frequency, amplitude, timeStamp);
    }

    public static void main(String[] args) throws IOException, InvalidMidiDataException {
        new PlayChordPerforated().test();
    }
}
