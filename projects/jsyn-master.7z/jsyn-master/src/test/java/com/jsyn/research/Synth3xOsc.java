package com.jsyn.research;

import com.jsyn.ports.UnitInputPort;
import com.jsyn.ports.UnitOutputPort;
import com.jsyn.ports.UnitVariablePort;
import com.jsyn.unitgen.UnitOscillator;

import static com.jsyn.research.Synth3xOsc.OscKind.*;

/**
 * Created by marodrig on 07/07/2015.
 */
public class Synth3xOsc extends UnitOscillator {

    public enum OscKind {Sine, Triangle, Square, Sawtooth}

    public long millis = 0;

    private UnitInputPort[] oscAmpl;
    private OscKind[] oscKind;

    /* Define Unit Ports used by connect() and set(). */
    public Synth3xOsc() {
        super();
        oscAmpl = new UnitInputPort[3];
        oscKind = new OscKind[3];
        oscKind[0] = OscKind.Sine;
        oscKind[1] = OscKind.Sine;
        oscKind[2] = OscKind.Sine;
        addPort(oscAmpl[0] = new UnitInputPort("Osc 1 Ampl", 1.0));
        addPort(oscAmpl[1] = new UnitInputPort("Osc 2 Ampl", 1.0));
        addPort(oscAmpl[2] = new UnitInputPort("Osc 3 Ampl", 1.0));
    }

    public Synth3xOsc(double freq) {
        this();
        frequency.set(freq);
    }

    public Synth3xOsc(double freq, double amp) {
        this();
        frequency.set(freq);
        amplitude.set(amp);
    }

    @Override
    public void generate(int start, int limit) {

        double[] frequencies = frequency.getValues();
        double[] amplitudes = amplitude.getValues();
        double[] outputs = output.getValues();

        double[][] oscAmp = new double[3][];
        oscAmp[0] = oscAmpl[0].getValues();
        oscAmp[1] = oscAmpl[1].getValues();
        oscAmp[2] = oscAmpl[2].getValues();

        double currentPhase = phase.getValue();


        long startMillis = System.nanoTime();
        for (int i = start; i < limit; i++) {

            double allAmpl = amplitudes[i] / (oscAmp[0][i] + oscAmp[1][i] + oscAmp[2][i]);

            double phaseIncrement = convertFrequencyToPhaseIncrement(frequencies[i]);
            currentPhase = incrementWrapPhase(currentPhase, phaseIncrement);

            outputs[i] = 0;
            for ( int k = 0; k < 3; k++) {
                double value = 0;
                switch (oscKind[k]) {
                    case Sine:
                        value = fastSin(currentPhase);
                        break;
                    case Sawtooth:
                        value = currentPhase;
                        break;
                    case Triangle:
                        value = (currentPhase >= 0.0) ? 1 - 2 * currentPhase : 1 + 2 * currentPhase;
                        break;
                    case Square:
                        value = (currentPhase >= 0) ? allAmpl : -allAmpl;
                        break;
                }
                outputs[i] += value * oscAmp[k][i] * allAmpl;
            }
        }
        millis += Math.abs(startMillis - System.nanoTime());

        phase.setValue(currentPhase);

    }

    /**
     * Calculate sine using Taylor expansion. Do not use values outside the range.
     *
     * @param currentPhase in the range of -1.0 to +1.0 for one cycle
     */
    public static double fastSin(double currentPhase) {
        // Factorial constants so code is easier to read.
        final double IF3 = 1.0 / (2 * 3);
        final double IF5 = IF3 / (4 * 5);
        final double IF7 = IF5 / (6 * 7);
        final double IF9 = IF7 / (8 * 9);
        final double IF11 = IF9 / (10 * 11);

        /* Wrap phase back into region where results are more accurate. */
        double yp = (currentPhase > 0.5) ? 1.0 - currentPhase : ((currentPhase < (-0.5)) ? (-1.0)
                - currentPhase : currentPhase);

        double x = yp * Math.PI;
        double x2 = (x * x);
        /* Taylor expansion out to x**11/11! factored into multiply-adds */
        double fastsin = x
                * (x2 * (x2 * (x2 * (x2 * ((x2 * (-IF11)) + IF9) - IF7) + IF5) - IF3) + 1);
        return fastsin;
    }

    public UnitInputPort getOsc1Ampl() {
        return oscAmpl[0];
    }

    public UnitInputPort getOsc2Ampl() {
        return oscAmpl[1];
    }

    public UnitInputPort getOsc3Ampl() {
        return oscAmpl[2];
    }

    public OscKind getOsc1Kind() {
        return oscKind[0];
    }

    public void setOsc1Kind(OscKind value) {
        this.oscKind[0] = value;
    }

    public OscKind getOsc2Kind() {
        return oscKind[1];
    }

    public void setOsc2Kind(OscKind value) {
        this.oscKind[1] = value;
    }

    public OscKind getOsc3Kind() {
        return oscKind[2];
    }

    public void setOsc3Kind(OscKind value) {
        this.oscKind[2] = value;
    }
}
