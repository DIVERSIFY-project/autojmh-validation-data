package com.jsyn.unitgen;

import com.jsyn.unitgen.MixerStereoRamped;
import com.jsyn.unitgen.Unzipper;

/**
 * Created by marodrig on 08/09/2015.
 */
public class MixerStereoRampendPerforated extends MixerStereoRamped {

    private Unzipper[] gainUnzippers;
    private Unzipper[] panUnzippers;
    private Unzipper amplitudeUnzipper;

    public MixerStereoRampendPerforated(int numInputs) {
        super(numInputs);
        gainUnzippers = new Unzipper[numInputs];
        for (int i = 0; i < numInputs; i++) {
            gainUnzippers[i] = new Unzipper();
        }
        panUnzippers = new Unzipper[numInputs];
        for (int i = 0; i < numInputs; i++) {
            panUnzippers[i] = new Unzipper();
        }
        amplitudeUnzipper = new Unzipper();
    }

    @Override
    public void generate(int start, int limit) {
        double[] amplitudes = amplitude.getValues(0);
        double[] outputs0 = output.getValues(0);
        double[] outputs1 = output.getValues(1);
        for (int i = start; i < limit; i++) {
            double sum0 = 0;
            double sum1 = 0;
            for (int n = 0; n < input.getNumParts(); n++) {
                double[] inputs = input.getValues(n);
                double[] gains = gain.getValues(n);
                double[] pans = pan.getValues(n);

                PanTracker panTracker = panTrackers[n];
                double smoothPan = panUnzippers[n].smooth(pans[i]);
                panTracker.update(smoothPan);

                double smoothGain = gainUnzippers[n].smooth(gains[i]);
                double scaledInput = inputs[i] * smoothGain;
                sum0 += scaledInput * panTracker.leftGain;
                sum1 += scaledInput * panTracker.rightGain;
            }
            double amp = amplitudeUnzipper.smooth(amplitudes[i]);
            outputs0[i] = sum0 * amp;
            outputs1[i] = sum1 * amp;
            //Perforated
            i++;
            if ( i < limit ) {
                outputs0[i] = outputs0[i - 1];
                outputs1[i] = outputs1[i - 1];
            }
        }
    }
}
